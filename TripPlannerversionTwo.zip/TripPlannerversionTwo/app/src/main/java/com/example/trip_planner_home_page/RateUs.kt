package com.example.trip_planner_home_page

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_rate_us.*

class RateUs : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rate_us)

     radioGroup_1.setOnCheckedChangeListener{ group, checkedId ->
         startActivity(Intent(this@RateUs, rateus_display_message::class.java))
     }

    }

}


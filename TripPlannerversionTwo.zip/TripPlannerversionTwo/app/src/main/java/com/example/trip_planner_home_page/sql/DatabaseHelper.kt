package com.example.trip_planner_home_page.sql


import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.trip_planner_home_page.model.City
import com.example.trip_planner_home_page.model.CityPackage
import com.example.trip_planner_home_page.model.Packages
import com.example.trip_planner_home_page.model.User

import java.util.*

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    // create table sql query
    private val CREATE_USER_TABLE = ("CREATE TABLE " + TABLE_USER + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_USER_NAME + " TEXT,"
            + COLUMN_USER_EMAIL + " TEXT," + COLUMN_USER_PASSWORD + " TEXT" + ")")

    private val CREATE_PACKAGE_TABLE = ("CREATE TABLE " + TABLE_PACKAGE + "("
            + COLUMN_PACKAGE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_PACKAGE_NAME + " TEXT,"
            + COLUMN_PACKAGE_DURATION + " TEXT," + COLUMN_PACKAGE_PRICE + " TEXT," + COLUMN_PACKAGE_T_D + " TEXT," + COLUMN_PACKAGE_INFORMATION + " TEXT" + ")")

    private val CREATE_CITY_TABLE = ("CREATE TABLE " + TABLE_CITY + "("
            + COLUMN_CITY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_CITY_FROM + " TEXT," + COLUMN_CITY_TO + " TEXT,"
            + COLUMN_CITY_ABOUT + " TEXT,"  + COLUMN_CITY_T_D + " TEXT," + COLUMN_CITY_PACKAGE + " TEXT" + ")")



    // drop table sql query
    private val DROP_USER_TABLE = "DROP TABLE IF EXISTS $TABLE_USER"
    private val DROP_PACKAGE_TABLE = "DROP TABLE IF EXISTS $TABLE_PACKAGE"
    private val DROP_CITY_TABLE = "DROP TABLE IF EXISTS $TABLE_CITY"


    override fun onCreate(db: SQLiteDatabase) {



        db.execSQL(CREATE_USER_TABLE)
        db.execSQL(CREATE_PACKAGE_TABLE)
        db.execSQL(CREATE_CITY_TABLE)

    }


    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

        //Drop User Table if exist
        db.execSQL(DROP_USER_TABLE)
        db.execSQL(DROP_PACKAGE_TABLE)
        db.execSQL(DROP_CITY_TABLE)

        // Create tables again
        onCreate(db)

    }

    /**
     * This method is to fetch all user and return the list of user records
     *
     * @return list
     */
    fun getAllUser(): List<User> {

        // array of columns to fetch
        val columns = arrayOf(COLUMN_USER_ID, COLUMN_USER_EMAIL, COLUMN_USER_NAME, COLUMN_USER_PASSWORD)

        // sorting orders
        val sortOrder = "$COLUMN_USER_NAME ASC"
        val userList = ArrayList<User>()

        val db = this.readableDatabase

        // query the user table
        val cursor = db.query(TABLE_USER, //Table to query
            columns,            //columns to return
            null,     //columns for the WHERE clause
            null,  //The values for the WHERE clause
            null,      //group the rows
            null,       //filter by row groups
            sortOrder)         //The sort order
        if (cursor.moveToFirst()) {
            do {
                val user = User(
                    id = cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID)).toInt(),
                    name = cursor.getString(cursor.getColumnIndex(COLUMN_USER_NAME)),
                    email = cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)),
                    password = cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD))
                )

                userList.add(user)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return userList
    }


    /**
     * This method is to fetch all user and return the list of user records
     *
     * @return list
     */


    fun getAllCity(a:String?,b: String?): List<CityPackage> {

        // array of columns to fetch
        val columns = arrayOf(COLUMN_CITY_ID, COLUMN_CITY_FROM, COLUMN_CITY_TO, COLUMN_CITY_ABOUT, COLUMN_CITY_T_D,
            COLUMN_CITY_PACKAGE, COLUMN_PACKAGE_NAME, COLUMN_PACKAGE_DURATION, COLUMN_PACKAGE_PRICE,
            COLUMN_PACKAGE_INFORMATION)

        // sorting orders
        val sortOrder = "$COLUMN_CITY_ID ASC"
        val cityPackageList = ArrayList<CityPackage>()

        val db = this.readableDatabase

        var rawquery: String = "SELECT * FROM " + TABLE_CITY + " INNER JOIN " + TABLE_PACKAGE + " ON " +
                COLUMN_CITY_PACKAGE + " = " + COLUMN_PACKAGE_ID + " WHERE " + COLUMN_CITY_FROM +" = " + " \"$a\" " + " AND " + COLUMN_CITY_TO +" = " +" \"$b\" ";
        // query the user table
        val cursor = db.rawQuery(rawquery,null)         //The sort order
        if (cursor.moveToFirst()) {
            do {
                val cityPackage = CityPackage(id = cursor.getString(cursor.getColumnIndex(COLUMN_CITY_ID)).toInt(),
                    from = cursor.getString(cursor.getColumnIndex(COLUMN_CITY_FROM)),
                    to = cursor.getString(cursor.getColumnIndex(COLUMN_CITY_TO)),
                    about = cursor.getString(cursor.getColumnIndex(COLUMN_CITY_ABOUT)),
                    t_d = cursor.getString(cursor.getColumnIndex(COLUMN_CITY_T_D)),
                    name = cursor.getString(cursor.getColumnIndex(COLUMN_PACKAGE_NAME)),
                    duration = cursor.getString(cursor.getColumnIndex(COLUMN_PACKAGE_DURATION)),
                    price = cursor.getString(cursor.getColumnIndex(COLUMN_PACKAGE_PRICE)),
                    information = cursor.getString(cursor.getColumnIndex(COLUMN_PACKAGE_INFORMATION))
                     )

                cityPackageList.add(cityPackage)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return cityPackageList
    }


    /**
     * This method is to create user record
     *
     * @param user
     */
    fun addUser(user: User) {
        val db = this.writableDatabase

        val values = ContentValues()
        values.put(COLUMN_USER_NAME, user.name)
        values.put(COLUMN_USER_EMAIL, user.email)
        values.put(COLUMN_USER_PASSWORD, user.password)


        // Inserting Row
        db.insert(TABLE_USER, null, values)
        db.close()
    }
    /**
     * This method is to create package record
     *
     * @param packages
     */

    fun addPackage(packages: Packages) {
        val db = this.writableDatabase

        val valuesPackage = ContentValues()
        valuesPackage.put(COLUMN_PACKAGE_NAME, packages.name)
        valuesPackage.put(COLUMN_PACKAGE_DURATION, packages.duration)
        valuesPackage.put(COLUMN_PACKAGE_PRICE, packages.price)
        valuesPackage.put(COLUMN_PACKAGE_T_D,packages.t_d)
        valuesPackage.put(COLUMN_PACKAGE_INFORMATION,packages.information)

        db.insert(TABLE_PACKAGE, null, valuesPackage)
        db.close()
    }



    /**
     * This method is to create city record
     *
     * @param city
     */

    fun addCity(city: City) {
        val db = this.writableDatabase

        val valuescity = ContentValues()
        valuescity.put(COLUMN_CITY_FROM, city.from)
        valuescity.put(COLUMN_CITY_TO, city.to)
        valuescity.put(COLUMN_CITY_ABOUT, city.about)
        valuescity.put(COLUMN_CITY_T_D, city.t_d)
        valuescity.put(COLUMN_CITY_PACKAGE,city.package_no)

        db.insert(TABLE_CITY, null, valuescity)
        db.close()
    }





    /**
     * This method to update user record
     *
     * @param user
     */
    fun updateUser(user: User) {
        val db = this.writableDatabase

        val values = ContentValues()
        values.put(COLUMN_USER_NAME, user.name)
        values.put(COLUMN_USER_EMAIL, user.email)
        values.put(COLUMN_USER_PASSWORD, user.password)


        // updating row
        db.update(TABLE_USER, values, "$COLUMN_USER_ID = ?",
            arrayOf(user.id.toString()))
        db.close()
    }


    /**
     * This method to update package record
     *
     * @param packages
     */
    fun updatePackage(packages: Packages) {
        val db = this.writableDatabase

        val values = ContentValues()
        values.put(COLUMN_PACKAGE_NAME, packages.name)
        values.put(COLUMN_PACKAGE_DURATION, packages.duration)
        values.put(COLUMN_PACKAGE_PRICE, packages.price)
        values.put(COLUMN_PACKAGE_T_D,packages.t_d)
        values.put(COLUMN_PACKAGE_INFORMATION,packages.information)


        // updating row
        db.update(
            TABLE_PACKAGE, values, "$COLUMN_PACKAGE_ID = ?",
            arrayOf(packages.id.toString()))
        db.close()
    }



    /**
     * This method to update city record
     *
     * @param city
     */
    fun updateCity(city: City) {
        val db = this.writableDatabase

        val valuescity = ContentValues()
        valuescity.put(COLUMN_CITY_FROM, city.from)
        valuescity.put(COLUMN_CITY_TO, city.to)
        valuescity.put(COLUMN_CITY_ABOUT, city.about)
        valuescity.put(COLUMN_CITY_T_D, city.t_d)
        valuescity.put(COLUMN_CITY_PACKAGE, city.package_no)


        // updating row
        db.update(
            TABLE_CITY, valuescity, "$COLUMN_CITY_ID = ?",
            arrayOf(city.id.toString()))
        db.close()
    }





    /**
     * This method is to delete user record
     *
     * @param user
     */
    fun deleteUser(user: User) {

        val db = this.writableDatabase
        // delete user record by id
        db.delete(TABLE_USER, "$COLUMN_USER_ID = ?",
            arrayOf(user.id.toString()))
        db.close()


    }

    /**
     * This method is to delete packages record
     *
     * @param packages
     */


    fun deletePackage(packages: Packages) {

        val db = this.writableDatabase
        // delete user record by id
        db.delete(
            TABLE_PACKAGE, "${COLUMN_PACKAGE_ID}_ID = ?",
            arrayOf(packages.id.toString()))
        db.close()


    }



    /**
     * This method is to delete city record
     *
     * @param city
     */
    fun deleteCity(city: City) {

        val db = this.writableDatabase
        // delete user record by id
        db.delete(
            TABLE_CITY, "$COLUMN_CITY_ID = ?",
            arrayOf(city.id.toString()))
        db.close()


    }




    /**
     * This method to check user exist or not
     *
     * @param email
     * @return true/false
     */
    fun checkUser(email: String): Boolean {

        // array of columns to fetch
        val columns = arrayOf(COLUMN_USER_ID)
        val db = this.readableDatabase

        // selection criteria
        val selection = "$COLUMN_USER_EMAIL = ?"

        // selection argument
        val selectionArgs = arrayOf(email)

        // query user table with condition
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'jack@androidtutorialshub.com';
         */
        val cursor = db.query(TABLE_USER, //Table to query
            columns,        //columns to return
            selection,      //columns for the WHERE clause
            selectionArgs,  //The values for the WHERE clause
            null,  //group the rows
            null,   //filter by row groups
            null)  //The sort order


        val cursorCount = cursor.count
        cursor.close()
        db.close()

        if (cursorCount > 0) {
            return true
        }

        return false
    }

    /**
     * This method to check user exist or not
     *
     * @param email
     * @param password
     * @return true/false
     */
    fun checkUser(email: String, password: String): Boolean {

        // array of columns to fetch
        val columns = arrayOf(COLUMN_USER_ID)

        val db = this.readableDatabase

        // selection criteria
        val selection = "$COLUMN_USER_EMAIL = ? AND $COLUMN_USER_PASSWORD = ?"

        // selection arguments
        val selectionArgs = arrayOf(email, password)

        // query user table with conditions
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'jack@androidtutorialshub.com' AND user_password = 'qwerty';
         */
        val cursor = db.query(TABLE_USER,  //Table to query
            columns, //columns to return
            selection, //columns for the WHERE clause
            selectionArgs, //The values for the WHERE clause
            null,  //group the rows
            null, //filter by row groups
            null) //The sort order

        val cursorCount = cursor.count
        cursor.close()
        db.close()

        if (cursorCount > 0)
            return true

        return false

    }

    companion object {

        // Database Version
        private val DATABASE_VERSION = 1

        // Database Name
        private val DATABASE_NAME = "TripPlanner.db"

        // User table name
        private val TABLE_USER = "login_signup"
        private val TABLE_PACKAGE = "packagedetails"
        private val TABLE_CITY = "citydetails"



        // User Table Columns names
        private val COLUMN_USER_ID = "user_id"
        private val COLUMN_USER_NAME = "user_name"
        private val COLUMN_USER_EMAIL = "user_email"
        private val COLUMN_USER_PASSWORD = "user_password"


        //Package Table Columns name
        //..........................................................................................
        private val COLUMN_PACKAGE_ID = "package_id"
        private val COLUMN_PACKAGE_NAME = "name"
        private val COLUMN_PACKAGE_DURATION = "duration"
        private val COLUMN_PACKAGE_PRICE = "price"
        private val COLUMN_PACKAGE_T_D = "T_D"
        private val COLUMN_PACKAGE_INFORMATION = "information"

        //City Table Columns name
        //............................................................................................

        private val COLUMN_CITY_ID = "city_id"
        private val COLUMN_CITY_FROM = "city_from"
        private val COLUMN_CITY_TO = "city_to"
        private val COLUMN_CITY_ABOUT = "city_about"
        private val COLUMN_CITY_T_D = "city_t_d"
        private val COLUMN_CITY_PACKAGE = "city_package"


    }
}
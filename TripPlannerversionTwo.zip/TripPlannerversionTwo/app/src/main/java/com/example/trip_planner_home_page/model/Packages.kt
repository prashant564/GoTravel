package com.example.trip_planner_home_page.model

data class Packages (val id: Int = -1, val name: String, val duration: String, val price: String ,val t_d: String, val information: String)
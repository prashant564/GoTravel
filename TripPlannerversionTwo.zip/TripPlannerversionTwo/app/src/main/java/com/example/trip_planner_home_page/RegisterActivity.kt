package com.example.trip_planner_home_page

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.example.trip_planner_home_page.helpers.InputValidation
import com.example.trip_planner_home_page.model.User
import com.example.trip_planner_home_page.sql.DatabaseHelper
import kotlinx.android.synthetic.main.activity_register.*
import android.annotation.SuppressLint
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


private val TAG = "Dikkat aagyi"

class RegisterActivity : AppCompatActivity() , View.OnClickListener
{
    private val activity = this@RegisterActivity
    private lateinit var editText_name : EditText
    private lateinit var editText_email_id : EditText
    private lateinit var editText_password : EditText
    private lateinit var editText_confirm_password : EditText
    private lateinit var button_sign_up : Button
    private lateinit var button_login : Button
//    private lateinit var inputValidation : InputValidation
//    private lateinit var databaseHelper : DatabaseHelper


    // This method is to initialize views
    @SuppressLint("WrongViewCast")
    private fun initViews()
    {
        editText_name = findViewById(R.id.editText_name)
        editText_email_id = findViewById(R.id.editText_email_id)
        editText_password = findViewById(R.id.editText_password)
        editText_confirm_password = findViewById(R.id.editText_confirm_password)
        button_sign_up = findViewById(R.id.button_sign_up)
        button_login = findViewById(R.id.button_login)
    }

    // This method is to initialize listeners
    private fun initListeners()
    {
        button_sign_up!!.setOnClickListener(this)
        button_login!!.setOnClickListener(this)
    }

    //This method is to initialize objects to be used
//    private fun initObjects()
//    {
//        inputValidation = InputValidation(activity)
//        databaseHelper = DatabaseHelper(activity)
//    }

    // This implemented method is to listen the click on view
    // @param v
    override fun onClick(v: View)
    {
        when (v.id)
        {
            R.id.button_sign_up -> postDataToSQLite()
            R.id.button_login -> finish()
        }
    }

    // This method is to validate the input text fields and post data to SQLite
    private fun postDataToSQLite()
    {
//        if (!inputValidation!!.isInputEditTextFilled(editText_name , getString(R.string.error_message_name)))
//        {
//            return
//        }
//
//        if (!inputValidation!!.isInputEditTextFilled(editText_email_id , getString(R.string.error_message_email)))
//        {
//            return
//        }
//
//        if (!inputValidation!!.isInputEditTextEmail(editText_email_id , getString(R.string.error_message_email)))
//        {
//            return
//        }
//
//        if (!inputValidation!!.isInputEditTextFilled(editText_password , getString(R.string.error_message_password)))
//        {
//            return
//        }
//
//        if (!inputValidation!!.isInputEditTextMatches(editText_password, editText_confirm_password, getString(R.string.error_password_match)))
//        {
//            return
//        }

//        if (!databaseHelper!!.checkUser(editText_email_id!!.text.toString().trim()))
//        {
//            var user = User(name = editText_name!!.text.toString().trim(),
//                email = editText_email_id!!.text.toString().trim(),
//                password = editText_password!!.text.toString().trim())
//
//            databaseHelper!!.addUser(user)
            Log.d(TAG, "Registration Successful")
            Toast.makeText(this,"Registration Successful", Toast.LENGTH_SHORT).show()
            emptyInputEditText()
            startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
//        }
//        else
//        {
//            Log.d(TAG, "Email Already Exists")
//            Toast.makeText(this,"Email Already Exists", Toast.LENGTH_SHORT).show()
//        }
    }

    // This method is to empty all input edit text
    private fun emptyInputEditText()
    {
        editText_name!!.text = null
        editText_email_id!!.text = null
        editText_password!!.text = null
        editText_confirm_password!!.text = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // hiding the action bar
        supportActionBar!!.hide()

        // initializing the views
        initViews()

        // initializing the listeners
        initListeners()

        // initializing the objects


        imageButton_back.setOnClickListener {
            startActivity(Intent(this@RegisterActivity, LoginActivity::class.java))
        }

        imageButton_home.setOnClickListener {
            startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
        }

//        button_sign_up.setOnClickListener {
//            startActivity(Intent(this@sign_up_activity, login_activity::class.java))
//        }
//
//        button_login.setOnClickListener {
//            startActivity(Intent(this@sign_up_activity, login_activity::class.java))
//        }
    }
}
package com.example.trip_planner_home_page

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class rateus_display_message : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rateus_display_message)


    }
}

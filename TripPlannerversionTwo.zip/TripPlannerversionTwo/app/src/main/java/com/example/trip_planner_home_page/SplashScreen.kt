package com.example.trip_planner_home_page

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import java.lang.Exception
import android.content.Intent

class SplashScreen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash__screen)
        val background = object : Thread() {

            override fun run(){
                try {
                       Thread.sleep(3000)
                    startActivity(Intent(baseContext, LoginActivity::class.java))


                } catch (e: Exception){
                    e.printStackTrace()
                }

            }
        }
         background.start()
    }
}

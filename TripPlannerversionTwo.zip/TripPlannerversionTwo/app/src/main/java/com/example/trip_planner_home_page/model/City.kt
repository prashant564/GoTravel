package com.example.trip_planner_home_page.model

data class City (val id: Int = -1, val from: String, val to: String, val about: String ,val t_d: String, val package_no: String)

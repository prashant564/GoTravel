package com.example.trip_planner_home_page.model

data class CityPackage(val id: Int = -1, val from: String, val to: String, val about: String ,val t_d: String, val name: String, val duration: String, val price: String , val information: String)